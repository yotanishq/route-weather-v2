"use client";

import { motion } from "framer-motion";
import { Navbar } from "@/components/navbar";
import { HeroSection } from "@/components/hero-section";
import { RoutePlanner } from "@/components/route-planner";
import { InteractiveMap } from "@/components/interactive-map";
import { WeatherAnalytics } from "@/components/weather-analytics";
import { TransportFeasibility } from "@/components/transport-feasibility";
import { DashboardSections } from "@/components/dashboard-sections";
import { Footer } from "@/components/footer";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <HeroSection />

      {/* Main Map Section - Full width hero-like prominence */}
      <section className="relative py-8 lg:py-12">
        {/* Background decorations */}
        <div className="absolute inset-0 bg-gradient-to-b from-white via-slate-50/30 to-white pointer-events-none" />
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-white to-transparent pointer-events-none" />
        
        <div className="relative max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="flex items-center justify-between mb-6"
          >
            <div>
              <h2 className="text-2xl lg:text-3xl font-semibold text-foreground">Route Intelligence</h2>
              <p className="text-muted-foreground mt-1">Real-time weather visualization for your journey</p>
            </div>
            <div className="hidden md:flex items-center gap-2 text-sm text-muted-foreground">
              <span className="flex items-center gap-1.5 px-3 py-1.5 bg-primary/10 text-primary rounded-full text-xs font-medium">
                <span className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse" />
                Live Data
              </span>
            </div>
          </motion.div>

          {/* Map + Sidebars Layout */}
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
            {/* Left Sidebar - Route Planner */}
            <div className="xl:col-span-3 order-2 xl:order-1">
              <div className="xl:sticky xl:top-24 space-y-6">
                <RoutePlanner />
              </div>
            </div>

            {/* Center - Large Interactive Map */}
            <div className="xl:col-span-9 order-1 xl:order-2">
              <InteractiveMap />
            </div>
          </div>
        </div>
      </section>

      {/* Analytics Section */}
      <section className="py-12 lg:py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Section header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="mb-8"
          >
            <h2 className="text-2xl lg:text-3xl font-semibold text-foreground">Weather Intelligence</h2>
            <p className="text-muted-foreground mt-1">Detailed analytics and transport recommendations</p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Weather Analytics */}
            <WeatherAnalytics />
            
            {/* Transport Feasibility */}
            <div className="space-y-6">
              <TransportFeasibility />
            </div>
          </div>
        </div>
      </section>

      {/* Dashboard Overview Section */}
      <DashboardSections />

      {/* Footer */}
      <Footer />
    </div>
  );
}
